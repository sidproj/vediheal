import React from "react";

CheckoutModal = () => {
  return <div className="modalContainer">CheckoutModal</div>;
};

export default CheckoutModal;
